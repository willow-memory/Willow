"""kernel.py: answers questions from your own files. Python 3.9+, stdlib only.
    python kernel.py init    --box DIR --pile FOLDER --key FILE [--words FILE]
    python kernel.py init    --box DIR [--pile FOLDER] --from NAME=FOLDER|NAME=@LIST ... --key FILE
    python kernel.py bite    --box DIR "your question"
    python kernel.py propose --box DIR --file SUGGESTIONS.jsonl
    python kernel.py seal    --box DIR proposal:<sha256>
    python kernel.py decline --box DIR proposal:<sha256>
    python kernel.py verify  --box DIR
    python kernel.py out     --box DIR
    python kernel.py test

The pile (--pile) is your own folder, and it is only ever read. Your files
may live in several places instead, or as well: each --from is a source,
a folder or a list of files (one path a line), read where it is, never
copied; its passages are named under NAME. The box
(--box) is a folder this script keeps its record in. The key (--key) is a
file of 32 random bytes, readable only by you and kept outside the box: it
is what approves an answer.

    init     makes the box and your key, and links your folder. --words names
             your own words list, kept like the key: a line `due = next, later`
             reads your word "due" as any of the words your files use
    bite     a question against your files. An answer you approved for these
             words comes first (exit 0). Else up to three passages of your
             files that hold the question's words (exit 0: your files say it);
             a passage that only asks the question back is marked `echo` and
             answers nothing. Else nothing (exit 42). Web pages are read as
             the text they show
    propose  suggested answers (from a model, say), one JSON object a line:
             {path, data, cites, claim}. Each needs a plain relative path, a
             claim that says why, and cites only from what the last bite
             returned. One that passes waits for you (exit 42); nothing is
             written yet
    seal     your approval of one suggestion: an HMAC-SHA-256 over its exact
             hash, made with your key. Only then is it written, and given as
             the answer to its question
    decline  your No to one suggestion, proved with your key the same way:
             it is never offered again, and can't be sealed after
    verify   re-checks every row of the record and every approval and No: a
             forged one is never accepted, whatever it claims
    out      what is waiting for your approval (exit 42 while anything is)
    test     runs every step once in a temporary folder and checks eight
             properties

The record is one JSON line per step. Each row holds the SHA-256 of the row
before it, starting from 64 zeros, so editing any past row breaks the chain.
It keeps hashes and places (file and line), never the words of a question or
of your files. Writes take a file lock and are fsynced; a half-written last
line is refused, not repaired.

Exit codes:
    0   a person said it: your files hold it, or you approved it
    42  not enough to say a person said it is true
    2   refused: a bad command line, a box that isn't yours, a record that
        doesn't verify. Nothing is written past a break.
"""

from __future__ import annotations

# Python's own library and nothing else, never an add-on: the core reaches
# nothing that extends it, and runs the same with every add-on gone (CONST-III-6)
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import sys
import tempfile
import unicodedata
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

try:
    import fcntl
except ImportError:  # Windows: msvcrt locks a byte of the record instead
    fcntl = None  # type: ignore[assignment]
try:
    import msvcrt
except ImportError:
    msvcrt = None  # type: ignore[assignment]

GENESIS = "0" * 64
ALIVE, ESCALATE, REFUSED = 0, 42, 2  # 42: silence escalates to the person (CONST-0-6)
ROW_KEYS = {"n", "kind", "who", "family", "standing", "version", "ts", "prev", "hash"}
VERSION = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
WORD = re.compile(r"[^\W_]+")  # a word: letters and digits, no underscore
TOP = 3  # chunks served for a bite
HOLD = 0.5  # the share of a bite's words a chunk must hold
#: Words that never count toward holding a bite: "how do I bake sourdough
#: bread" is not held by a chunk that says "how" and "do". English; a bite in
#: another language keeps every word. "anything", "someone" and their kin name
#: no topic either: "did i promise siobhan anything" is held by the promise.
FUNCTION = frozenset(
    "a an the and or but if of to in on at by for from with about as into than"
    " then so is are was were be been being am do does did done have has had i"
    " me my we our you your he she it its they them their this that these those"
    " what which who whom whose when where why how much many can could would"
    " should will shall may might must not no yes there here s t"
    " anything something nothing everything anyone someone everyone anybody"
    " somebody everybody nobody anywhere somewhere everywhere nowhere".split()
)
SNIFF = 8192  # bytes looked at to tell text from binary: a NUL byte means binary
MAX_FILE = 1_000_000  # bytes read from one file of the pile
MAX_CHUNK = 500  # characters in one chunk


# ── the record ──────────────────────────────────────────────────────────────
def canon(row: dict) -> str:
    """Canonical JSON: keys sorted, no spaces, UTF-8 kept as is."""
    return json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def h256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def read(path: Path) -> tuple[list[dict], list[str]]:
    """(rows, breaks). Every break is said; an empty list means the chain holds."""
    if not path.exists():
        return [], []
    data = path.read_bytes().decode("utf-8")
    if data and not data.endswith("\n"):
        # append-only; repairing it is a person's act, never this code's (CONST-0-5)
        return [], ["torn tail: the last line is unterminated; a human looks first"]
    rows, breaks, prev = [], [], GENESIS
    # "\n" only: canon keeps a raw U+2028,
    # U+2029 or U+0085 in a string (a file name in a served `where`), and
    # str.splitlines() would cut the row there and brick the box
    lines = data.split("\n")[:-1] if data else []
    for i, line in enumerate(lines):
        try:
            row = json.loads(line)
        except ValueError:
            row = None
        if not isinstance(row, dict) or not ROW_KEYS <= row.keys():
            breaks.append(f"line {i}: garbled, not a record row")
            continue
        body = {k: v for k, v in row.items() if k != "hash"}
        if row["prev"] != prev or h256(canon(body)) != row["hash"]:
            breaks.append(f"row {row['n']}: chain broken")
        if isinstance(row["n"], bool) or row["n"] != len(rows):
            breaks.append(f"row {row['n']!r}: out of place, it is row {len(rows)}")
        rows.append(row)
        prev = row["hash"]
    return rows, breaks


def append(box: Path, ts: str, kind: str, who: str = "kernel", **fields) -> dict:
    """One row on the chain, under a lock, fsynced with its directory."""
    path = box / "record.jsonl"
    with path.open("a+", encoding="utf-8", newline="") as f:
        lock(f)
        rows, breaks = read(path)  # the true tail, read under the lock
        if breaks:
            raise RuntimeError("; ".join(breaks))
        # only the person ratifies (CONST-0-2)
        sealed = kind == "seal" and who == "human"
        row = {"n": len(rows), "kind": kind, "who": who, "family": "kernel"}
        row.update(standing="sealed" if sealed else "unattested", version=VERSION)
        row.update(ts=ts, where=fields.pop("where", None), **fields)
        row["prev"] = rows[-1]["hash"] if rows else GENESIS
        row["hash"] = h256(canon(row))
        f.write(canon(row) + "\n")
        f.flush()
        os.fsync(f.fileno())
    if row["n"] == 0 and hasattr(os, "O_DIRECTORY"):  # the new name survives a crash
        d = os.open(box, os.O_DIRECTORY)
        try:
            os.fsync(d)
        finally:
            os.close(d)
    return row


def lock(f) -> None:
    """One writer at a time: flock where there is one; on Windows, msvcrt's
    lock on the record's first byte, tried until it is free (its own retry
    gives up after ten seconds)."""
    if fcntl is not None:
        fcntl.flock(f, fcntl.LOCK_EX)
    elif msvcrt is not None:
        f.seek(0)
        while True:
            try:
                msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
                return
            except OSError:
                continue


# ── the seal and the bite key ───────────────────────────────────────────────
def proof(key: bytes, subject: str, act: str = "seal", asked: str | None = None) -> str:
    """HMAC-SHA-256 under their key, over the act ("seal", or "decline" for a
    No), a unit separator, the subject; and, for a seal that names the
    question it answers, another separator and that question's key."""
    parts = (act, subject) if asked is None else (act, subject, asked)
    return hmac.new(key, "\x1f".join(parts).encode(), hashlib.sha256).hexdigest()


def words(text: str) -> list[str]:
    """A text's words, lowercased and composed (NFC): a file that spells é as
    e and a combining accent, as macOS often saves it, holds the é you type."""
    return WORD.findall(unicodedata.normalize("NFC", text.lower()))


def bite_key(text: str) -> str | None:
    """The SHA-256 of the words in order, one space between: the same question
    retyped in another case or punctuation has the same key."""
    ws = words(text)
    return h256(" ".join(ws)) if ws else None


def subject_of(prop: dict) -> str:
    keys = ("path", "data", "cites", "claim")
    return "proposal:" + h256(canon({k: prop[k] for k in keys}))


# ── the box: theirs ─────────────────────────────────────────────────────────
def config(box: Path) -> dict:
    return json.loads((box / "kernel.json").read_text(encoding="utf-8"))


def read_key(path: Path, box: Path) -> tuple[bytes | None, str | None]:
    """Their key: hex in a file outside the box, readable only by them. It is
    the human key the constitution requires (CONST-0-4)."""
    if path.resolve().is_relative_to(box.resolve()):
        return None, "the key can't live inside the box"
    try:
        if os.name == "posix" and path.stat().st_mode & 0o077:
            return None, f"{path} is readable beyond its owner; chmod 600 it"
        return bytes.fromhex(path.read_text(encoding="utf-8").strip()), None
    except (OSError, ValueError) as e:
        return None, f"the key could not be read: {type(e).__name__}"


def parse_words(text: str) -> tuple[dict[str, list[str]], str | None]:
    """Their words list: a line `due = next, overdue` reads their word "due"
    as any of their folder's words after the `=`. Blank lines and `#` lines
    are skipped; one word on the left, one word between each comma."""
    out: dict[str, list[str]] = {}
    for n, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        left, eq, right = s.partition("=")
        theirs = [words(x) for x in right.split(",")]
        if not eq or len(words(left)) != 1 or any(len(t) != 1 for t in theirs):
            return (
                {},
                f"words list line {n}: one word = one or more words, a comma between",
            )
        mine = out.setdefault(words(left)[0], [])
        for [t] in theirs:
            if t != words(left)[0] and t not in mine:
                mine.append(t)
    return {w: sorted(ts) for w, ts in out.items() if ts}, None


def read_words(path: Path, box: Path) -> tuple[dict | None, str, str | None]:
    """Their words list, kept like their key: outside the box, readable only
    by them. Returns (the list, its SHA-256, why not)."""
    if path.resolve().is_relative_to(box.resolve()):
        return None, "", "the words list can't live inside the box"
    try:
        if os.name == "posix" and path.stat().st_mode & 0o077:
            return None, "", f"{path} is readable beyond its owner; chmod 600 it"
        raw = path.read_bytes()
        text = raw.decode("utf-8")
    except (OSError, ValueError) as e:
        return None, "", f"the words list could not be read: {type(e).__name__}"
    alias, why = parse_words(text)
    return (None, "", why) if why else (alias, hashlib.sha256(raw).hexdigest(), None)


def source_of(given: str) -> tuple[str, str] | str:
    """(name, folder or @list) from NAME=FOLDER or NAME=@LIST, or why not."""
    name, eq, at = given.partition("=")
    if not eq or not name or at in ("", "@"):
        return f"{given}: a source is NAME=FOLDER or NAME=@LIST"
    if "/" in name or "\\" in name or name.startswith("."):
        return f"{name}: a source's name is plain, no / and not starting with ."
    where = Path(at[1:] if at.startswith("@") else at)
    if at.startswith("@"):
        if not where.is_file():
            return f"{where}: a list of files is a file, and isn't there"
        gone = [f for f in listed(where) if not f.is_file()]
        if gone:
            return f"{where} names {len(gone)} file{'' if len(gone) == 1 else 's'} that aren't there, the first {gone[0]}"
        return name, "@" + str(where.resolve())
    if not where.is_dir():
        return f"{where} is not a folder"
    return name, str(where.resolve())


def init(
    box: Path,
    pile: Path | None,
    key: Path,
    ts: str,
    wl: Path | None = None,
    froms: list[str] | None = None,
) -> int:
    if (box / "record.jsonl").exists():
        print("refused: this box already has a record", file=sys.stderr)
        return REFUSED
    if pile is not None and not pile.is_dir():
        print(f"refused: {pile} is not a folder", file=sys.stderr)
        return REFUSED
    found: dict[str, str] = {}
    for given in froms or []:
        got = source_of(given)
        if isinstance(got, str):
            print(f"refused: {got}", file=sys.stderr)
            return REFUSED
        if got[0] in found:
            print(f"refused: {got[0]}: a source's name is given once", file=sys.stderr)
            return REFUSED
        if pile is not None and (pile / got[0]).exists():
            print(
                f"refused: {got[0]}: the pile already holds that name at its top",
                file=sys.stderr,
            )
            return REFUSED
        found[got[0]] = got[1]
    if pile is None and not found:
        print("refused: a box reads a pile folder, sources, or both", file=sys.stderr)
        return REFUSED
    if key.resolve().is_relative_to(box.resolve()):
        print("refused: the key can't live inside the box", file=sys.stderr)
        return REFUSED
    if wl is not None and (why := read_words(wl, box)[2]) is not None:
        print(f"refused: {why}", file=sys.stderr)
        return REFUSED
    if not key.exists():
        key.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(secrets.token_hex(32) + "\n")
    box.mkdir(parents=True, exist_ok=True)
    cfg = {"key": str(key.resolve())}
    placed = {}
    if pile is not None:
        cfg["pile"] = str(pile.resolve())
        placed["pile_sha256"] = h256(cfg["pile"])
    if found:  # where each source is read, never a copy of it (CONST-VI-9)
        cfg["sources"] = found
        placed["sources_sha256"] = h256(canon(found))
    if wl is not None:
        cfg["words"] = str(wl.resolve())
    (box / "kernel.json").write_text(json.dumps(cfg, sort_keys=True) + "\n")
    row = append(box, ts, "boot", loop="open", **placed)
    print(f"ready: record started, row {row['n']} {row['hash'][:16]}")
    return ALIVE


# ── the pile: their own folder, chunked by paragraph ────────────────────────
_HIDDEN = re.compile(r"<(script|style)\b.*?</\1\s*>|<!--.*?-->", re.S | re.I)
_TAG = re.compile(r"<[^>]*>", re.S)


def _lines_kept(m: re.Match) -> str:
    return " " + "\n" * m.group(0).count("\n")  # line numbers still point home


def html_text(text: str) -> str:
    """The words a page shows: scripts, styles, comments and tags out, entities
    read, every line where it was. A first bite on a page is never served
    `<button>` and `<!doctype>`."""
    return html.unescape(_TAG.sub(_lines_kept, _HIDDEN.sub(_lines_kept, text)))


def stem(w: str) -> str:
    """An English word's plain form, by a few suffix rules, so owe, owes, owed
    and owing are one word (Hollis's "who still owes me money", Teodora's "how
    much do I still owe dev"). Only words of ASCII letters: another language,
    or a serial, is left as written; "eed" stays, so feed is never fee (bug
    #308). Irregular forms (paid) are her words list's job."""
    if len(w) < 3 or not (w.isascii() and w.isalpha()):
        return w
    s = w
    if len(s) > 4 and s[-3:] in ("ies", "ied"):
        s = s[:-3] + "y"
    elif len(s) > 4 and s.endswith("ing"):
        s = s[:-3]
    elif len(s) > 3 and s.endswith("ed") and not s.endswith("eed"):
        s = s[:-2]
    elif len(s) > 3 and s.endswith("s") and not s.endswith("ss"):
        s = s[:-1]
    if len(s) > 3 and s[-1] == s[-2] and s[-1] not in "aeiouls":
        s = s[:-1]  # running, planned
    if len(s) > 2 and s.endswith("e"):
        s = s[:-1]
    return s


def forms(ws) -> set[str]:
    """Words, and each one's plain form (`stem`)."""
    out = set(ws)
    return out | {stem(w) for w in out}


def holds(w: str, toks: set[str]) -> bool:
    """A word holds where it is a token, or its plain form is (`toks` built
    by `forms`); one with a digit in it (a VIN, a serial, a case number) also
    holds where a token starts or ends with it: "that one ending 672841"
    finds 1HGEJ6672841."""
    if w in toks or stem(w) in toks:
        return True
    return (
        len(w) >= 4
        and any(c.isdigit() for c in w)
        and any(t.endswith(w) or t.startswith(w) for t in toks)
    )


ECHO_RUN = 8  # words in a row, in the bite's order, that make a chunk an echo


def echo(bite: str, text: str) -> bool:
    """Whether `text` holds the bite's own words in its own order: the whole
    bite, or `ECHO_RUN` of its words in a row (a long opener never fits in one
    chunk whole). The question asked back is not its answer."""
    ws, ts = words(bite), words(text)
    n = min(len(ws), ECHO_RUN)
    if n < 3:
        return False
    runs = {tuple(ts[i : i + n]) for i in range(len(ts) - n + 1)}
    return any(tuple(ws[i : i + n]) in runs for i in range(len(ws) - n + 1))


def _chunked(p: Path, rel: str) -> list[dict]:
    """One file's paragraphs, as `chunks` cuts them; none when it is not text
    the kernel reads (too big, a binary, not UTF-8, not there)."""
    try:  # text by what it holds, not by its name: a newcomer's TODO,
        # deploy.bat and login.php are theirs to ask about
        if p.stat().st_size > MAX_FILE or b"\0" in (raw := p.read_bytes())[:SNIFF]:
            return []
        text = raw.decode("utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    if p.suffix.lower() in (".html", ".htm"):
        text = html_text(text)
    out, para, start, size = [], [], 1, 0
    for i, line in enumerate(text.splitlines() + [""], 1):
        if para and (not line.strip() or size + len(line) > MAX_CHUNK):
            body = "\n".join(para)  # a paragraph, or a run of one under the cap
            out.append({"path": rel, "line": start, "text": body, "id": h256(body)})
            para, size = [], 0
        if line.strip():
            if not para:
                start = i
            para.append(line[:MAX_CHUNK])
            size += len(para[-1]) + 1
    return out


def chunks(pile: Path) -> list[dict]:
    """Every paragraph of every text file under `pile` (any name; UTF-8 with no
    NUL byte in its first `SNIFF` bytes), cut into runs of at most
    `MAX_CHUNK` characters (a file with no blank lines would otherwise be one
    chunk holding every word, served for any bite): where it starts, its text,
    its SHA-256. Hidden folders, binaries and anything not UTF-8 are left out."""
    out = []
    for p in sorted(pile.rglob("*")):
        rel = p.relative_to(pile)
        if not p.is_file() or any(part.startswith(".") for part in rel.parts):
            continue
        out += _chunked(p, str(rel))
    return out


# ── sources: the person's files, read where they are kept (CONST-VI-9) ─────
def listed(lst: Path) -> list[Path]:
    """The files a list names, in its order, each once: one path a line, a
    blank line or a # line skipped, a relative path from the list's folder."""
    out: list[Path] = []
    for line in lst.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            f = Path(line)
            f = (f if f.is_absolute() else lst.parent / f).resolve()
            if f not in out:
                out.append(f)
    return out


def list_chunks(lst: Path) -> list[dict]:
    """A list's files read where they are, each named by its path from the
    folder the listed files share, in that name's order, as `chunks` orders a
    folder's; a file not there now is read as nothing, as a deleted one is."""
    files = listed(lst)
    if not files:
        return []
    root = Path(os.path.commonpath([str(f.parent) for f in files]))
    out = []
    for rel, f in sorted((f.relative_to(root), f) for f in files):
        if not any(part.startswith(".") for part in rel.parts):
            out += _chunked(f, str(rel))
    return out


def sources(cfg: dict) -> dict[str, Path]:
    """The box's sources, {name: folder or list}, a list as its file."""
    return {
        k: Path(v[1:] if v.startswith("@") else v)
        for k, v in cfg.get("sources", {}).items()
    }


def pile_of_box(cfg: dict) -> list[dict]:
    """Everything the box reads: its pile folder's passages, as `chunks` reads
    them, then each source's in name order, each named NAME/ and its path.
    ValueError when a source's name is a name at the top of the pile folder,
    since their passages could not be told apart."""
    out = chunks(Path(cfg["pile"])) if "pile" in cfg else []
    tops = {Path(c["path"]).parts[0] for c in out}
    for name, at in sorted(sources(cfg).items()):
        if name in tops:
            raise ValueError(
                f"the source {name} has the name of a file or folder at the top of the pile"
            )
        part = list_chunks(at) if cfg["sources"][name].startswith("@") else chunks(at)
        out += [{**c, "path": f"{name}/{c['path']}", "source": name} for c in part]
    return out


def place(cfg: dict, rel: str) -> Path:
    """Where a passage's file is: a path the pile names (`law/charter.md`)
    as the file it was read from, in its source or the pile folder."""
    name, _, rest = rel.partition("/")
    at = cfg.get("sources", {}).get(name)
    if at is None or not rest:
        return Path(cfg["pile"]) / rel
    if not at.startswith("@"):
        return Path(at) / rest
    files = listed(Path(at[1:]))
    return Path(os.path.commonpath([str(f.parent) for f in files])) / rest


def folder(cfg: dict) -> Path:
    """The box's one pile folder, for a reader that walks a folder itself;
    ValueError when the box reads sources, which such a reader would miss."""
    if cfg.get("sources") or "pile" not in cfg:
        raise ValueError(
            "this box reads its files where they are kept, from several places; this reads one folder (CONST-VI-9)"
        )
    return Path(cfg["pile"])


def _digits(text: str, i: int) -> int:
    """How many ASCII digits run from `i`."""
    j = i
    while j < len(text) and "0" <= text[j] <= "9":
        j += 1
    return j - i


def _date(y: str, m: str, d: str) -> str:
    """YYYYMMDD when it reads as a date (years 1900-2099), else "": a day
    the month has, so 1984-06-31 and 2023-02-29 are no date and 2024-02-29
    is (a year divisible by 4 leaps, a century only when divisible by 400)."""
    ok = y[:2] in ("19", "20") and "01" <= m <= "12" and "01" <= d <= "31"
    if ok and m == "02":
        n = int(y)
        ok = d <= ("29" if n % 4 == 0 and (n % 100 != 0 or n % 400 == 0) else "28")
    elif ok and m in ("04", "06", "09", "11"):
        ok = d <= "30"
    return y + m + d if ok else ""


def _day_month(a: str, b: str, y: str) -> str:
    """A date written a/b/y or a.b.y, as YYYYMMDD, only when it can't be
    misread: one of a and b over 12 says which is the day, or they're equal.
    11/03/2023 could be either, and the kernel never guesses."""
    x, z = int(a), int(b)
    if x == z or x > 12 >= z:  # 5/5 reads the same either way
        return _date(y, f"{z:02d}", f"{x:02d}")
    if z > 12 >= x:
        return _date(y, f"{x:02d}", f"{z:02d}")
    return ""


def _web_address(text: str, i: int) -> int:
    """How many characters from `i` are an http(s) address, or 0."""
    for scheme in ("http://", "https://"):
        if text.startswith(scheme, i):
            j = i + len(scheme)
            while j < len(text) and not text[j].isspace():
                j += 1
            return j - i
    return 0


def newest(text: str) -> str:
    """The latest date written in `text`, as YYYYMMDD, or "" for none: an ISO
    date (2026-10-14), a compact one (20261014, a calendar's), or a day and a
    month either way round with a four-digit year (21/10/2026, 10.21.2026),
    read only when one part is over 12. Each a whole run of ASCII digits, never
    part of a longer number, and not inside a web address. Read by hand, not
    by a regex, so a port reads the same dates."""
    best, i = "", 0
    while i < len(text):
        if url := _web_address(text, i):
            i += url
            continue
        n = _digits(text, i)
        if n == 0:
            i += 1
            continue
        got = ""
        if n == 8:
            got = _date(text[i : i + 4], text[i + 4 : i + 6], text[i + 6 : i + 8])
        elif n == 4 and text[i + 4 : i + 5] == "-" and _digits(text, i + 5) == 2:
            if text[i + 7 : i + 8] == "-" and _digits(text, i + 8) == 2:
                got = _date(text[i : i + 4], text[i + 5 : i + 7], text[i + 8 : i + 10])
                if got:
                    n = 10
        elif n <= 2 and (sep := text[i + n : i + n + 1]) in ("/", "."):
            m = _digits(text, i + n + 1)
            j = i + n + 1 + m
            if 1 <= m <= 2 and text[j : j + 1] == sep and _digits(text, j + 1) == 4:
                got = _day_month(
                    text[i : i + n], text[i + n + 1 : j], text[j + 1 : j + 5]
                )
                if got:
                    n = j + 5 - i
        best = max(best, got)
        i += n
    return best


def own_path(c: dict) -> str:
    """A chunk's path as its own folder names it: a source's name places a
    passage and is no word of it (CONST-VI-9), or a source named "recipes"
    would hand every passage in it the word for free (#366)."""
    return c["path"][len(c["source"]) + 1 :] if c.get("source") else c["path"]


def toks(c: dict) -> set[str]:
    """A chunk's words: its text's and its path's. A folder's name is the
    person's word too: Laszlo's care log never says "Dad", its folder does."""
    return forms(words(c["text"]) + words(own_path(c)))


def held_by(w: str, toks: set[str], alias: dict) -> bool:
    """Their word holds where it, or a word their list reads it as, does."""
    return any(holds(x, toks) for x in [w, *alias.get(w, [])])


def _held(pile: list[dict], want: set[str], alias: dict, days: list[int]) -> list:
    """(chunk, date, the words it holds) for each chunk holding `HOLD` of
    `want`, in pile order."""
    held = [
        (c, d, {w for w in want if held_by(w, toks(c), alias)})
        for c, d in zip(pile, days)
    ]
    return [(c, d, h) for c, d, h in held if len(h) >= HOLD * len(want)]


def holding(pile: list[dict], bite: str, alias: dict | None = None) -> list[dict]:
    """Every chunk `rank` would weigh for the bite, in pile order, none left
    out for `TOP` and none for a copy: the passages that hold it."""
    want = set(words(bite)) - FUNCTION
    if not want:
        return []
    return [c for c, *_ in _held(pile, want, alias or {}, [0] * len(pile))]


def rank(
    pile: list[dict],
    bite: str,
    alias: dict | None = None,
    top: int | None = None,
    dated=None,
) -> list[dict]:
    """The chunks holding at least `HOLD` of the bite's content words (not
    `FUNCTION`) in their text or their path (`toks`), rarest words weighing
    most; among equal scores, the newest
    first (`dates`), then by path, and in one file a dated chunk's later line
    first (a log grows downward). A chunk sharing only "the" or
    "how" and "do" doesn't hold "when does the frost come" or "how do I bake
    sourdough bread": an answer it doesn't have is never improvised (beat 1).
    A bite of function words alone is held by nothing: say more. `alias` is
    their words list (`parse_words`). `top` serves more than `TOP` (an
    add-on listing every match); `dated` gives each chunk's date in place of
    `dates` (an index that has them already). Neither changes the order."""
    want = set(words(bite)) - FUNCTION
    if not want:
        return []
    held = _held(pile, want, alias or {}, (dated or dates)(pile))
    df = {w: sum(w in h for *_, h in held) for w in want}
    # the same question, the same answer (CONST-IV-10). Exact, not float: a float sum's last bit depends on the order the set is
    # walked in, which is the process's hash seed, so on Python 3.9-3.11 the
    # same folder and bite ranked differently from run to run (13 runs in 400
    # on one pile); 3.12's compensated sum hides it, and a port can't copy that
    scored = [
        (sum(Fraction(1, df[w]) for w in h), d, c["path"], c["line"], c)
        for c, d, h in held
        if h
    ]
    # a log grows downward: on one date, the later line is the newer one
    # among equal scores, what was said once before what is said every week
    # (the same text, one id, many places), then the newest
    copies: dict[str, int] = {}
    for c in pile:
        copies[c["id"]] = copies.get(c["id"], 0) + 1
    order = sorted(
        scored,
        key=lambda s: (-s[0], copies[s[4]["id"]], -s[1], s[2], -s[3] if s[1] else s[3]),
    )
    # a place is for something not yet shown: a memo she dictates every month
    # is one text, one id, and served once (Odile's jar order, twice, pushed
    # out the van memo she still has to act on)
    out: list[dict] = []
    for *_, c in order:
        if len(out) == (TOP if top is None else top):
            break
        if all(c["id"] != x["id"] for x in out):
            out.append(c)
    return out


def dates(pile: list[dict]) -> list[int]:
    """Each chunk's date as a number to sort by (0 for none): the latest date
    in its path or text, or above it in its file, since a log's date heading
    covers the lines under it. `pile` is in `chunks` order."""
    out, path, cur = [], None, ""
    for c in pile:
        if c["path"] != path:
            path, cur = c["path"], newest(own_path(c))
        cur = max(cur, newest(c["text"]))
        out.append(int(cur or 0))
    return out


# ── where to look: what a 42 (or a served definition) can still say ─────────
# Facts about their folder first; then, at most, which kind of tool does the
# rest. A newcomer is told where the answer could be, never handed a guess.
DEFINES = re.compile(r"\b(?:def|function|sub|class|func|fn)\s+([A-Za-z_][A-Za-z0-9_]*)")
MAKE = {"make", "build", "write", "create", "generate"}
NEXT = {
    "other words": "add it to your words list, or use a search that matches by meaning",
    "unused": "a code search or call graph can say what calls it",
    "made": "this reads what your files hold; making something needs another tool",
}


def look(
    pile: list[dict],
    bite: str,
    served: list[dict],
    alias: dict | None = None,
) -> list[dict]:
    """Where to look, from what the folder holds: the bite's words no file
    has; each function a served chunk defines, and whether anything else in
    the folder names it (text can show a definition, not that nothing calls
    it); a bite of common words only; a request to make something. Anything
    more is built on top, never in here."""
    out = []
    ws = words(bite)
    want = [w for w in dict.fromkeys(ws) if w not in FUNCTION]
    if not want:
        out.append({"why": "every word is a common one: name the thing you mean"})
    every = set()
    for c in pile:
        every |= toks(c)
    alias = alias or {}
    absent = [w for w in want if not held_by(w, every, alias)]
    for w in want:  # said, so a match their list made is never taken for theirs
        if not holds(w, every) and (
            read := [x for x in alias.get(w, []) if holds(x, every)]
        ):
            out.append({"why": f"read {w} as {', '.join(read)}, from your words list"})
    if absent:
        out.append(
            {
                "why": "no file in your folder has " + ", ".join(absent),
                "where": "it may be called something else there",
                "next": NEXT["other words"],
            }
        )
    for c in served:
        for name in dict.fromkeys(DEFINES.findall(c["text"])):
            named = re.compile(rf"\b{re.escape(name)}\b")
            uses = sorted(
                {d["path"] for d in pile if d is not c and named.search(d["text"])}
                | ({c["path"]} if len(named.findall(c["text"])) > 1 else set())
            )
            out.append(
                {
                    "why": f"{name} is defined at {c['path']}:{c['line']}",
                    "where": "also named in " + ", ".join(uses)
                    if uses
                    else "nothing else in your folder names it",
                    "next": NEXT["unused"],
                }
            )
    if ws and ws[0] in MAKE:
        out.append({"why": "this asks for something made", "next": NEXT["made"]})
    return out


# ── the loop ────────────────────────────────────────────────────────────────
def sealed(box: Path, rows: list[dict], act: str = "seal") -> dict[str, dict]:
    """Each proposal a seal row holds, by subject, only while its proof holds
    under the person's key. A forged seal is in neither: it is reported by
    `verify`, and never served (CONST-0-2, CONST-0-4). A seal row that names
    a question (`bite_key`) is proved over it too, so the question is the
    person's to name; one from before that has no such field and is proved
    the old way. With act "decline", the same for the person's No."""
    key, _ = read_key(Path(config(box)["key"]), box)
    out = {}
    for r in rows:
        if r["kind"] == act and key is not None:
            asked = r.get("bite_key") if act == "seal" and "bite_key" in r else None
            if "bite_key" in r and act == "seal" and not isinstance(asked, str):
                continue
            if hmac.compare_digest(
                proof(key, r.get("subject", ""), act, asked), str(r.get("proof"))
            ):
                out[r["subject"]] = r
    return out


def proposed_under(
    rows: list[dict], subj: str, before: int | None = None
) -> str | None:
    """The question a proposal was last made under, from the record: the
    bite its last passing proposal row names (before row `before`, if given).
    None when the record names none."""
    last = None
    for r in rows:
        if before is not None and r["n"] >= before:
            break
        if r["kind"] == "proposal" and r.get("subject") == subj:
            if r.get("verdict") == "pass":
                last = r
    i = last.get("bite_row") if last else None
    if isinstance(i, bool) or not isinstance(i, int) or not 0 <= i < len(rows):
        return None
    key = rows[i].get("bite_key") if rows[i]["kind"] == "bite" else None
    return key if isinstance(key, str) else None


def standing(
    box: Path, rows: list[dict], subj: str, seal: dict
) -> tuple[dict | None, str | None, str | None]:
    """What a seal stands on: (the proposal, the question it was sealed for,
    None), or (None, None, why not). The key signed the subject, the hash of
    the proposal's bytes, so the file is served only while it still hashes to
    that (CONST-0-4); and the question is the one the seal names, which its
    proof covers. A seal from before that names none, and takes the record's:
    the bite the proposal was made under before the seal. Never a field of
    the file."""
    try:
        prop = json.loads((box / "proposals" / f"{subj[9:]}.json").read_text())
        same = subject_of(prop) == subj
    except (OSError, ValueError, KeyError, TypeError):
        return None, None, "is missing or can't be read"
    if not same:
        return None, None, "is not the bytes that were sealed"
    key = (
        seal["bite_key"]
        if "bite_key" in seal
        else proposed_under(rows, subj, seal["n"])
    )
    if key is None:
        return None, None, "was made under no question the record names"
    return prop, key, None


def declined(box: Path, rows: list[dict]) -> dict[str, dict]:
    """Each proposal the person declined, by subject, while its proof holds."""
    return sealed(box, rows, "decline")


def waiting(box: Path, rows: list[dict]) -> dict[str, dict]:
    """What waits on the person: each proposal that passed the door and that
    they neither sealed nor declined, by subject, its first passing row, in
    the order first proposed. Counted once a thing to decide (CONST-V-11)."""
    good, no = sealed(box, rows), declined(box, rows)
    out: dict[str, dict] = {}
    for r in rows:
        if r["kind"] == "proposal" and r.get("verdict") == "pass":
            s = r.get("subject")
            if s not in good and s not in no and s not in out:
                out[s] = r
    return out


def offered(box: Path, rows: list[dict], subj: str) -> str | None:
    """Why a suggestion that passed the door isn't offered again, or None:
    what waits, was sealed or was declined is offered once (CONST-V-11)."""
    for why, held in (
        ("you approved it at row", sealed(box, rows)),
        ("you declined it at row", declined(box, rows)),
        ("already waiting on your seal, row", waiting(box, rows)),
    ):
        if subj in held:
            return f"{why} {held[subj]['n']}"
    return None


def bite(box: Path, text: str, ts: str) -> int:
    rows, breaks = read(box / "record.jsonl")
    if breaks:
        print("refused:", *breaks, sep="\n  ", file=sys.stderr)
        return REFUSED
    k = bite_key(text)
    if k is None:
        print("refused: a bite with no words", file=sys.stderr)
        return REFUSED
    for subj, row in sealed(
        box, rows
    ).items():  # a sealed answer for these words, first
        prop, asked, why = standing(box, rows, subj, row)
        if why is None and asked == k:
            append(box, ts, "bite", bite_key=k, answered_by=subj, served=[])
            print(json.dumps({"state": "sealed", "answer": prop["data"], "by": subj}))
            return ALIVE
    alias, listed = {}, {}
    if "words" in (cfg := config(box)):
        alias, sha, why = read_words(Path(cfg["words"]), box)
        if why is not None:
            print(f"refused: {why}", file=sys.stderr)
            return REFUSED
        listed = {"words_sha256": sha}
    try:
        passages = pile_of_box(cfg)
    except ValueError as e:
        print(f"refused: {e}", file=sys.stderr)
        return REFUSED
    served = rank(passages, text, alias)
    refs = [
        {
            "id": c["id"],
            "where": f"{c['path']}:{c['line']}",
            "echo": echo(text, c["text"]),
        }
        for c in served
    ]
    # hashes and places, never the words asked or served (CONST-VI-8)
    append(box, ts, "bite", bite_key=k, served=refs, **listed)
    answers = [r for r in refs if not r["echo"]]
    state = "populated" if answers else "echo" if refs else "empty"
    doc = {"state": state, "bite_key": k}
    doc["served"] = [{**r, "text": c["text"]} for r, c in zip(refs, served)]
    if hints := look(passages, text, served if answers else [], alias):
        doc["look"] = hints  # printed for them; the record keeps no words
    print(json.dumps(doc, ensure_ascii=False))
    return ALIVE if answers else ESCALATE


def door(prop: object, served: set[str]) -> str | None:
    """Why a proposed row doesn't pass, or None. A suggestion reaches no
    further than the box and what the last bite served (CONST-0-3)."""
    keys = {"path", "data", "cites", "claim"}
    if not isinstance(prop, dict) or set(prop) != keys:
        return "a row is exactly {path, data, cites, claim}"
    p = prop["path"]
    if (
        not isinstance(p, str)
        or not p
        or p.startswith(("/", "\\"))
        or ".." in Path(p).parts
    ):
        return "a path is plain and relative, inside the box"
    if not isinstance(prop["data"], str) or not isinstance(prop["cites"], list):
        return "data is text and cites a list"
    if not isinstance(prop["claim"], str) or not prop["claim"].strip():
        return "a claim says why"
    if not set(prop["cites"]) <= served:
        return "a cite that the last bite didn't serve"
    return None


def propose(box: Path, lines: list[str], ts: str) -> int:
    rows, breaks = read(box / "record.jsonl")
    if breaks:
        print("refused:", *breaks, sep="\n  ", file=sys.stderr)
        return REFUSED
    last = next((r for r in reversed(rows) if r["kind"] == "bite"), None)
    if last is None:
        print("refused: propose answers a bite; bite first", file=sys.stderr)
        return REFUSED
    served = {s["id"] for s in last.get("served", [])}
    for i, line in enumerate(lines):
        try:
            prop = json.loads(line)
        except ValueError:
            prop = None
        why = door(prop, served)
        if why is None:
            why = offered(box, read(box / "record.jsonl")[0], subject_of(prop))
        if why is None:
            subj = subject_of(prop)
            (box / "proposals").mkdir(exist_ok=True)
            kept = {**prop, "bite_key": last["bite_key"]}
            (box / "proposals" / f"{subj[9:]}.json").write_text(json.dumps(kept))
            append(
                box, ts, "proposal", subject=subj, verdict="pass", bite_row=last["n"]
            )
            print(f"pass  {subj}  waiting on your seal")
        else:
            append(box, ts, "proposal", verdict="refused", line=i, why=why)
            print(f"refused  line {i}: {why}")
    # Passing the door is not acceptance: nothing `propose` reads is an answer
    # until the person seals it (CONST-0-1).
    return ESCALATE


def seal(box: Path, subj: str, ts: str) -> int:
    rows, breaks = read(box / "record.jsonl")
    if breaks:
        print("refused:", *breaks, sep="\n  ", file=sys.stderr)
        return REFUSED
    if not any(r["kind"] == "proposal" and r.get("subject") == subj for r in rows):
        print(f"refused: {subj} is not a proposal in this box", file=sys.stderr)
        return REFUSED
    if subj in (no := declined(box, rows)):  # a no is final (CONST-V-10)
        print(f"refused: you declined {subj} at row {no[subj]['n']}", file=sys.stderr)
        return REFUSED
    key, why = read_key(Path(config(box)["key"]), box)
    if key is None:
        print(f"refused: {why}", file=sys.stderr)
        return REFUSED
    prop = json.loads((box / "proposals" / f"{subj[9:]}.json").read_text())
    if subject_of(prop) != subj:  # approved bytes are proposed bytes (CONST-0-4)
        print(
            "refused: the proposal's bytes changed since it was proposed",
            file=sys.stderr,
        )
        return REFUSED
    asked = proposed_under(rows, subj)  # the question this is the answer to
    if asked is None:
        print(
            f"refused: the record names no question {subj} was made under",
            file=sys.stderr,
        )
        return REFUSED
    append(
        box, ts, "seal", who="human", subject=subj, bite_key=asked,
        proof=proof(key, subj, "seal", asked),
    )  # fmt: skip
    out = box / "written" / prop["path"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(prop["data"], encoding="utf-8")
    print(f"sealed {subj}; written to {out.relative_to(box)}")
    return ALIVE


def decline(box: Path, subj: str, ts: str) -> int:
    rows, breaks = read(box / "record.jsonl")
    if breaks:
        print("refused:", *breaks, sep="\n  ", file=sys.stderr)
        return REFUSED
    if not any(r["kind"] == "proposal" and r.get("subject") == subj for r in rows):
        print(f"refused: {subj} is not a proposal in this box", file=sys.stderr)
        return REFUSED
    for done, said in (
        (sealed(box, rows), "sealed"),
        (declined(box, rows), "declined"),
    ):
        if subj in done:
            print(
                f"refused: you {said} {subj} at row {done[subj]['n']}", file=sys.stderr
            )
            return REFUSED
    key, why = read_key(Path(config(box)["key"]), box)
    if key is None:
        print(f"refused: {why}", file=sys.stderr)
        return REFUSED
    append(
        box, ts, "decline", who="human", subject=subj, proof=proof(key, subj, "decline")
    )
    print(f"declined {subj}; it won't be offered again")
    return ALIVE


def verify(box: Path) -> int:
    rows, breaks = read(box / "record.jsonl")
    if breaks:
        print("\n".join(breaks))
        return REFUSED
    good = sealed(box, rows)
    forged = [
        r["n"] for r in rows if r["kind"] == "seal" and r.get("subject") not in good
    ]
    no = declined(box, rows)
    nos = [
        r["n"] for r in rows if r["kind"] == "decline" and r.get("subject") not in no
    ]
    drifted = []
    for subj, row in good.items():
        prop, _, why = standing(box, rows, subj, row)
        if why is None and prop.get("bite_key") != proposed_under(rows, subj):
            why = "names another question than the record"
        if why is not None:
            drifted.append((subj, why))
    for subj, why in drifted:
        print(f"the chain holds; {subj} is sealed, but its proposal file {why}")
    if forged:
        print(f"the chain holds; seal rows {forged} don't prove under your key")
    if nos:
        print(f"the chain holds; decline rows {nos} don't prove under your key")
    if forged or nos or drifted:
        return ESCALATE
    print(f"the chain holds: {len(rows)} rows, {len(good)} sealed")
    return ALIVE


def out(box: Path, ts: str) -> int:
    rows, breaks = read(box / "record.jsonl")
    if breaks:
        print("refused:", *breaks, sep="\n  ", file=sys.stderr)
        return REFUSED
    good = sealed(box, rows)
    # what they declined is not offered again (CONST-V-10), and what waits is
    # counted once (CONST-V-11)
    owed = waiting(box, rows)
    append(box, ts, "out", waiting=len(owed), tip=rows[-1]["hash"] if rows else GENESIS)
    for s in owed:
        print(f"waiting on your seal: {s}")
    print(f"{len(rows) + 1} rows; {len(good)} sealed; {len(owed)} waiting")
    return ESCALATE if owed else ALIVE


# ── the thirteen beats, as the test ─────────────────────────────────────────
def test() -> None:
    """Runs in a temporary directory, never in a box of yours."""
    import ast
    import contextlib
    import importlib.util
    import io
    import subprocess
    import sysconfig

    def quiet(fn, *a):
        with contextlib.redirect_stdout(io.StringIO()) as o:
            with contextlib.redirect_stderr(io.StringIO()):
                return fn(*a), o.getvalue()

    def foreign(source: str) -> set[str]:
        """What a source imports that isn't Python's own: built in, frozen,
        or under its lib folder. fcntl and msvcrt are each the other
        system's; a relative import is never the standard library's."""
        lib = Path(sysconfig.get_paths()["stdlib"]).resolve()
        found = set()
        for node in ast.walk(ast.parse(source)):
            if isinstance(node, ast.Import):
                found |= {a.name.split(".")[0] for a in node.names}
            elif isinstance(node, ast.ImportFrom):
                found.add("." * node.level + (node.module or "").split(".")[0])
        out = set()
        for name in found - {"__future__", "fcntl", "msvcrt"}:
            if name in sys.builtin_module_names:
                continue
            spec = None if name.startswith(".") else importlib.util.find_spec(name)
            origin = spec.origin if spec else None
            if origin in ("built-in", "frozen"):
                continue
            if not origin or lib not in Path(origin).resolve().parents:
                out.add(name)
            elif "site-packages" in origin:
                out.add(name)
        return out

    def kept(v) -> list[str]:
        """Every string a row holds but its places (`where`)."""
        if isinstance(v, dict):
            return [s for k, x in v.items() if k != "where" for s in kept(x)]
        if isinstance(v, list):
            return [s for x in v for s in kept(x)]
        return [] if v is None else [str(v)]

    #: the record's own labels: the kernel's words, never a person's
    LABELS = ("kind", "who", "family", "standing", "loop", "verdict")
    #: a pile where a float sum's last bit, and so the order of two chunks,
    #: followed the hash seed on Python 3.11 (found by search, 2026-10-21)
    SEED_PILE = (
        "w1 w6|w3 w1 w0 w2|w4 w2 w0 w5 w3|w2 w3 w0 w4 w1|w4 w1 w3 w5|"
        "w2 w6 w1 w3 w0|w5 w0 w2 w1|w5 w1 w0|w2 w4 w1|w3 w6 w1 w4 w5 w2|"
        "w5 w3 w6|w1 w2 w3 w6 w0 w4|w5 w2 w4"
    )

    with tempfile.TemporaryDirectory() as tmp:
        t, ts = Path(tmp), "2026-10-22T00:00:00Z"
        pile, box, key = t / "pile", t / "box", t / "keys" / "me.key"
        pile.mkdir()
        (pile / "garden.md").write_text(
            "Tomatoes want six hours of sun.\n\nWater at the root.\n"
        )
        assert quiet(init, box, pile, key, ts)[0] == ALIVE
        (pile / "big.json").write_text(
            "\n".join(f'"k{i}": "word{i} of {i}"' for i in range(400))
        )
        # 1. asked what nobody here has said: it says so, it doesn't improvise,
        #    and a long file with no blank line doesn't answer everything
        assert quiet(bite, box, "when does the frost come", ts)[0] == ESCALATE
        assert quiet(bite, box, "how do I bake sourdough bread", ts)[0] == ESCALATE
        assert quiet(bite, box, "what does this do", ts)[0] == ESCALATE  # say more
        # what the demos' characters needed: a page read as text, a serial by
        # its ending, and a question asked back not taken for its answer
        (pile / "lot.html").write_text(
            "<html><script>var lot = 1;</script>\n<p>The blue Civic,"
            " VIN 1HGEJ6672841, one owner.</p></html>\n"
        )
        code, said = quiet(bite, box, "the one ending 672841", ts)
        hit = json.loads(said)["served"][0]
        assert (
            code == ALIVE and hit["where"] == "lot.html:2" and "<p>" not in hit["text"]
        )
        (pile / "faq.md").write_text("Has the shed been painted this year?\n")
        code, said = quiet(bite, box, "has the shed been painted this year", ts)
        assert code == ESCALATE and json.loads(said)["state"] == "echo"
        (pile / "shed.md").write_text(
            "Has the shed out back been painted this year or not, and by whom?\n"
        )
        long = "so I was out back this morning and wondered: has the shed out back been painted this year"
        code, said = quiet(bite, box, long, ts)  # a long opener holding the question
        assert code == ESCALATE and json.loads(said)["state"] == "echo"
        assert all(len(c["text"]) <= MAX_CHUNK for c in chunks(pile))
        # their own pile answers what it holds (things they already said yes to)
        code, said = quiet(bite, box, "how much sun do tomatoes want", ts)
        assert code == ALIVE and "six hours" in said
        cite = json.loads(said)["served"][0]["id"]
        row = {
            "path": "notes/sun.md",
            "data": "Six hours.",
            "cites": [cite],
            "claim": "from garden.md",
        }
        f = t / "rows.jsonl"
        f.write_text(
            json.dumps(row) + "\n" + json.dumps({**row, "cites": ["nope"]}) + "\n"
        )
        code, said = quiet(propose, box, f.read_text().splitlines(), ts)
        assert code == ESCALATE and "refused  line 1" in said  # a cite not served
        subj = subject_of(row)
        # 2. the person verifies it, once, with their own key
        assert quiet(seal, box, subj, ts)[0] == ALIVE
        assert (box / "written" / "notes/sun.md").read_text() == "Six hours."
        # 3. the same question, retyped differently, is served as sealed
        code, said = quiet(bite, box, "How much SUN do tomatoes want?!", ts)
        assert code == ALIVE and json.loads(said)["by"] == subj
        # 4. a rewrite with other words is not served as sealed
        code, said = quiet(bite, box, "tomatoes want how much sun", ts)
        assert "sealed" not in json.loads(said)["state"]
        # 5. an unsealed proposal is not an answer: out says it waits
        code, said = quiet(bite, box, "water them at the root?", ts)
        water = json.loads(said)["served"][0]["id"]
        unsealed = {
            **row,
            "path": "notes/water.md",
            "data": "At the root.",
            "cites": [water],
        }
        f.write_text(json.dumps(unsealed) + "\n")
        assert quiet(propose, box, f.read_text().splitlines(), ts)[0] == ESCALATE
        code, said = quiet(out, box, ts)
        assert code == ESCALATE and subject_of(unsealed) in said
        # 6. a forged seal (the right shape, the chain re-hashed) is never served
        fake = subject_of(unsealed)
        append(box, ts, "seal", who="human", subject=fake, proof="0" * 64)
        assert fake not in sealed(box, read(box / "record.jsonl")[0])
        assert quiet(verify, box)[0] == ESCALATE
        # 7. a no is final (CONST-V-10): a No that doesn't prove counts for
        #    nothing, and one that does ends the offer and bars the seal
        append(box, ts, "decline", who="human", subject=fake, proof="0" * 64)
        assert fake in quiet(out, box, ts)[1]
        assert quiet(decline, box, fake, ts)[0] == ALIVE
        code, said = quiet(out, box, ts)
        assert code == ALIVE and fake not in said
        assert quiet(seal, box, fake, ts)[0] == REFUSED
        # 8. the same question, the same answer, under every hash seed
        #    (CONST-IV-10): a pile where a float sum once followed the seed
        (pile / "seed").mkdir()
        for i, text in enumerate(SEED_PILE.split("|")):
            (pile / "seed" / f"f{i:02d}.md").write_text(text + "\n")
        runs = {
            subprocess.run(
                [sys.executable, __file__, "bite", "--box", str(box), "--now", ts]
                + ["w4 w2 w6 w1 w3 w0"],
                capture_output=True,
                text=True,
                env={**os.environ, "PYTHONHASHSEED": seed},
            ).stdout
            for seed in ("0", "101", "156")
        }
        assert len(runs) == 1
        got = [s["where"] for s in json.loads(runs.pop())["served"]]
        assert got == ["seed/f11.md:1", "seed/f05.md:1", "seed/f09.md:1"]
        # 9. the core reaches nothing that extends it (CONST-III-6): every
        #    module this file imports is Python's own, and none is an add-on
        # (a stand-in name, never an add-on's: this file names none)
        planted = "import json\nfrom extends_me.part import thing\nfrom . import near\n"
        assert foreign(planted) == {"extends_me", "."}
        assert foreign(Path(__file__).read_text(encoding="utf-8")) == set()
        # 10. the record keeps acts, not words (CONST-VI-8): after the whole
        #     cycle, no word it holds is one a question or a suggestion said
        asked = [
            "when does the frost come",
            "how do I bake sourdough bread",
            "the one ending 672841",
            "has the shed been painted this year",
            long,
            "how much sun do tomatoes want",
            "water them at the root?",
            "Six hours. At the root.",
        ]
        said = {w for q in asked for w in words(q)} - FUNCTION
        held = set()
        for r in read(box / "record.jsonl")[0]:
            held |= set(words(" ".join(kept({**r, **dict.fromkeys(LABELS)}))))
        assert "tomatoes" in said and not said & held, said & held
        # 11. offered once, counted once (CONST-V-11): what was sealed, was
        #     declined or waits is refused at the door, and counted once
        quiet(bite, box, "tomatoes want how much sun", ts)
        f.write_text(json.dumps(row) + "\n")
        said = quiet(propose, box, f.read_text().splitlines(), ts)[1]
        assert said.startswith("refused  line 0: you approved it at row"), said
        quiet(bite, box, "water them at the root?", ts)
        deep = {**unsealed, "data": "Deep."}
        f.write_text("".join(json.dumps(x) + "\n" for x in (unsealed, deep, deep)))
        said = quiet(propose, box, f.read_text().splitlines(), ts)[1].splitlines()
        assert said[0].startswith("refused  line 0: you declined it at row"), said
        assert said[1] == f"pass  {subject_of(deep)}  waiting on your seal", said
        assert said[2].startswith("refused  line 2: already waiting on your seal, row")
        # a record from before the door: one subject passed twice, still once
        rows = read(box / "record.jsonl")[0]
        held = next(r for r in rows if r.get("subject") == subject_of(deep))
        append(box, ts, "proposal", subject=held["subject"], verdict="pass",
               bite_row=held["bite_row"])  # fmt: skip
        code, said = quiet(out, box, ts)
        assert code == ESCALATE and said.count("waiting on your seal") == 1
        # 12. the chain verifies, every step on it
        rows, breaks = read(box / "record.jsonl")
        assert not breaks and [r["n"] for r in rows] == list(range(len(rows)))
        # 13. one field of one past row edited: the chain refuses, and so does the next bite
        path = box / "record.jsonl"
        path.write_bytes(
            path.read_bytes().replace(b'"verdict":"pass"', b'"verdict":"fail"', 1)
        )
        assert quiet(verify, box)[0] == REFUSED
        assert quiet(bite, box, "how much sun do tomatoes want", ts)[0] == REFUSED
        # 14. read where they are kept (CONST-VI-9): a box of its pile and two
        #     sources, a folder and a list, answers from each where it is,
        #     each passage named under its source, and an edit to the original
        #     after the box was made is what the next bite reads
        law, notes, both = t / "law", t / "notes", t / "both"
        law.mkdir()
        notes.mkdir()
        (law / "charter.md").write_text("The shed is painted every fourth spring.\n")
        (notes / "roof.md").write_text("The roof estimate was 4200.\n")
        (notes / "not-listed.md").write_text("The roof estimate was 9999.\n")
        lst = t / "chosen.txt"
        lst.write_text("# the one asked for\nnotes/roof.md\n")
        froms = [f"law={law}", f"chosen=@{lst}"]
        assert (
            quiet(init, both, pile, t / "keys" / "two.key", ts, None, froms)[0] == ALIVE
        )
        cfg = config(both)
        got = [(c["path"], c["text"]) for c in pile_of_box(cfg)]
        assert ("law/charter.md", "The shed is painted every fourth spring.") in got
        assert ("chosen/roof.md", "The roof estimate was 4200.") in got
        assert not any("9999" in x for _, x in got)
        mine = [c for c in pile_of_box(cfg) if c["path"].startswith("law/")]
        assert [(c["line"], c["text"], c["id"]) for c in mine] == [
            (c["line"], c["text"], c["id"]) for c in chunks(law)
        ]
        # a source's name places a passage and is no word of it (#366)
        assert "law" not in toks(mine[0]) and "charter" in toks(mine[0])
        (notes / "roof.md").write_text("The roof estimate is now 4300.\n")
        said = json.loads(quiet(bite, both, "the roof estimate", ts)[1])
        assert [x["where"] for x in said["served"]] == ["chosen/roof.md:1"]
        assert "4300" in said["served"][0]["text"]
    print("kernel: the fourteen beats held")


# ── the command line ────────────────────────────────────────────────────────
def main(argv: list[str]) -> int:
    if argv[:1] == ["test"]:
        test()
        return ALIVE
    verb, rest = (argv[0], argv[1:]) if argv else ("", [])
    opts: dict[str, str] = {}
    args: list[str] = []
    froms: list[str] = []
    it = iter(rest)
    for a in it:
        if a in ("--box", "--pile", "--key", "--file", "--now", "--words"):
            opts[a] = next(it, "")
        elif a == "--from":
            froms.append(next(it, ""))
        else:
            args.append(a)
    if "--box" not in opts or not opts["--box"]:
        print(__doc__.split("\n\n")[0], file=sys.stderr)
        return REFUSED
    box, ts = Path(opts["--box"]), opts.get("--now") or now()
    if (
        verb == "init"
        and (opts.get("--pile") or froms)
        and "" not in froms
        and ("--pile" not in opts or opts["--pile"])
        and opts.get("--key")
        and not args
    ):
        wl = Path(opts["--words"]) if opts.get("--words") else None
        pile_at = Path(opts["--pile"]) if opts.get("--pile") else None
        return init(box, pile_at, Path(opts["--key"]), ts, wl, froms)
    if froms:  # a source is named when the box is made, and only then
        print(__doc__.split("\n\n")[0], file=sys.stderr)
        return REFUSED
    if not (box / "kernel.json").exists():
        print("refused: not a kernel box; init first", file=sys.stderr)
        return REFUSED
    if verb == "bite" and len(args) == 1:
        return bite(box, args[0], ts)
    if verb == "propose" and opts.get("--file") and not args:
        return propose(
            box, Path(opts["--file"]).read_text(encoding="utf-8").splitlines(), ts
        )
    if verb == "seal" and len(args) == 1 and args[0].startswith("proposal:"):
        return seal(box, args[0], ts)
    if verb == "decline" and len(args) == 1 and args[0].startswith("proposal:"):
        return decline(box, args[0], ts)
    if verb == "verify" and not args:
        return verify(box)
    if verb == "out" and not args:
        return out(box, ts)
    print(__doc__.split("\n\n")[0], file=sys.stderr)
    return REFUSED


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
